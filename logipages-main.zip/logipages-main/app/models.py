from django.db import models

from django.contrib.auth.models import User

# Create your models here.

class profiles(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    name=models.CharField(default="venkat (default)",max_length=200,null=True)
    title=models.CharField(default="this is  (default),title you can chenge profile",max_length=200,null=True)
    desc_text="hey this is default text you can chenge after your profile is created"
    desc=models.CharField(default="desc_text",max_length=200,null=True)
    profile_img=models.ImageField(default="images.jpg",upload_to="images",null=True,blank=True)


    def __str__(self):
        return self.name
