from django.urls import path
from app.views import *

from django.conf import settings

from django.conf.urls.static import static

urlpatterns=[
    path("index/",index,name="index"),
    path("profile/",profile_user,name="profile"),
    path("login/",login_user,name="login"),
    path("logout/",logout_user,name="logout"),
    path("register/",registr_user,name="register"),
]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)