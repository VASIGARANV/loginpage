from django.contrib import admin
from app.models import *
# Register your models here.


class userdata(admin.ModelAdmin):
    list_display=["user","name","title","desc_text","desc","profile_img"]



admin.site.register(profiles,userdata)