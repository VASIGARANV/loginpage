from django.shortcuts import render,redirect
from django.http import HttpResponse


from app.models import *
from app.forms import *

from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.decorators import login_required

from django.core.mail import  send_mail

# Create your views here.

def index(request):
    username=""
    d={"username":username}
    if request.session.get("username"):
        username=request.session.get("username")
        d={"username":username}
    return render(request,"home.html",d)


@login_required
def profile_user(request):
    ud=request.session.get("username")
    udf=User.objects.get(username=ud)
    pdf=profiles.objects.get(user=udf)
    print(pdf)
    return render(request,"profile.html",{"udf":udf,"pdf":pdf})




def login_user(request):
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user=authenticate(username=username,password=password)

        if user and user.is_active:
            login(request,user)
            request.session["username"]=username
            return redirect("index")
        else:
            return HttpResponse("youer not a valid user")


    return render(request,"login.html")


@login_required
def logout_user(request):
    logout(request)
    return redirect("index")





def registr_user(request):
    uf = User_form()
    pf = profile_form()

    if request.method == "POST" and request.FILES:
        UFD = User_form(request.POST)
        PFD = profile_form(request.POST, request.FILES)
        
        if UFD.is_valid() and PFD.is_valid():
            # Save the user form, but don't commit yet
            user = UFD.save(commit=False)
            print(user)
            
            # Set the password properly
            user.set_password(UFD.cleaned_data['password'])
            user.save()

            # Save the profile form
            profile = PFD.save(commit=False)
            print(profile)
            profile.user = user  # Assign the user instance to the profile
            profile.save()

            send_mail('registrations',
                    "",
                    'n.venkateswarlu180@gmail.com',
                    [user.email],
                    fail_silently=False)

            return HttpResponse("User registered successfully")

    return render(request, "register.html", {"uf": uf, "pf": pf})


