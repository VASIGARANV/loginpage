from django import forms
from app.models import *


class User_form(forms.ModelForm):
    class Meta:
        model=User
        fields=["username","password","email"]
        widgets={"password":forms.PasswordInput}



class profile_form(forms.ModelForm):
    class Meta:
        model=profiles
        fields=["name","profile_img"]